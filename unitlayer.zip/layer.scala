
abstract class Layer {
  type T = Double
  var is_test = false
  def forward(x: Array[T]): Array[T]
  def backward(x: Array[T]): Array[T]
  def forward(xs: Array[Array[T]]): Array[Array[T]] = {
    xs.map(forward)
  }
  def backward(ds: Array[Array[T]]): Array[Array[T]] = {
    ds.reverse.map(backward).reverse
  }
  def update(): Unit
  def reset(): Unit
  def save(fn: String) {}
  def load(fn: String) {}
}
