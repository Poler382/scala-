import math._
import breeze.linalg._

/*
l8-l132:Affine
l134-262:Convolition3D
 */

class Affine(val xn: Int, val yn: Int,
  val eps: Double = 0.001, val rho1: Double = 0.9, val rho2: Double = 0.999) extends Layer {
  val rand = new scala.util.Random(0)

  var W = Array.ofDim[T](xn * yn).map(_ => rand.nextGaussian * 0.01)
  var b = Array.ofDim[T](yn)
  var dW = Array.ofDim[T](xn * yn)
  var db = Array.ofDim[T](yn)
  var n = 0

  def windex(i: Int, j: Int) = i * xn + j

  var xs = List[Array[T]]()

  def push(x: Array[T]) = {
    xs ::= x;
    x
  }

  def pop() = {
    val x = xs.head;
    xs = xs.tail;
    x
  }

  def forward(x: Array[T]) = {
    push(x)
    val y = Array.ofDim[T](yn)
    for (i <- 0 until yn) {
      for (j <- 0 until xn) {
        y(i) += W(windex(i, j)) * x(j)
      }
      y(i) += b(i)
    }
    y
  }

  def backward(d: Array[T]) = {
    val x = pop()
    n += 1

    for (i <- 0 until yn; j <- 0 until xn) {
      dW(windex(i, j)) += d(i) * x(j)
    }

    for (i <- 0 until yn) {
      db(i) += d(i)
    }

    val dx = Array.ofDim[T](xn)
    for (j <- 0 until yn; i <- 0 until xn) {
      dx(i) += W(windex(j, i)) * d(j)
    }

    dx
  }

  def update() {
    for (i <- 0 until dW.size) {
      dW(i) /= n
    }
    for (i <- 0 until db.size) {
      db(i) /= n
    }
    update_adam()
    reset()
  }


  var adam_W = new Adam(W.size, eps, rho1, rho2)
  var adam_b = new Adam(b.size, eps, rho1, rho2)

  def update_adam() {
    adam_W.update(W, dW)
    adam_b.update(b, db)
  }

  var lr = 0.001

  def update_sgd() {
    for (i <- 0 until W.size) {
      W(i) -= lr * dW(i)
    }

    for (i <- 0 until b.size) {
      b(i) -= lr * db(i)
    }
  }

  def reset() {
    for (i <- 0 until dW.size) {
      dW(i) = 0d
    }
    for (i <- 0 until db.size) {
      db(i) = 0d
    }
    xs = List[Array[T]]()
    n = 0
  }

  override def save(fn: String) {
    val pw = new java.io.PrintWriter(fn)
    for (i <- 0 until W.size) {
      pw.write(W(i).toString)
      if (i != W.size - 1) {
        pw.write(",")
      }
    }
    pw.write("\n")
    for (i <- 0 until b.size) {
      pw.write(b(i).toString)
      if (i != b.size - 1) {
        pw.write(",")
      }
    }
    pw.write("\n")
    pw.close()
  }

  override def load(fn: String) {
    val f = scala.io.Source.fromFile(fn).getLines.toArray
    W = f(0).split(",").map(_.toDouble).toArray
    b = f(1).split(",").map(_.toDouble).toArray
  }
}

class Convolution3D(
  val KW:Int,val IH:Int,val IW:Int,val IC:Int,val OC:Int,
  val ss:Int=1,
  val e:Double = 0.01,
  val p1:Double = 0.9)extends Layer {
  val OH = 1 + (IH-KW)/ss //IH - KW + 1
  val OW = 1 + (IW-KW)/ss // w - kw + 1
  val rand = new scala.util.Random(0)
  var t=0
  var p1_t=1d
  var p2_t=1d
  var K = Array.ofDim[T](OC,IC,KW*KW).map(_.map(_.map(a => rand.nextGaussian*0.01)))
  var V_D = List[Array[T]]()
  var D_K = Array.ofDim[T](OC,IC,KW*KW)
  var s = Array.ofDim[T](OC,IC,KW*KW)
  var r = Array.ofDim[T](OC,IC,KW*KW)
  var n = 0d

  def iindex(i:Int, j:Int, k:Int) = i * IH*IW + j * IW + k
  def oindex(i:Int, j:Int, k:Int) = i * OH*OW + j * OW + k
 
  def push(V:Array[T]) = { V_D ::= V; V }
  def pop() = { val V = V_D.head; V_D = V_D.tail; V }
 
  def forward(V:Array[T]) = {
    push(V)
    val Z = Array.ofDim[T](OC*OH*OW)//1 + (IW-KW)/ss)

    for(i<-0 until OC ; j<-0 until OH ; k<-0 until OW){
      var s = 0d
      for(l<-0 until IC ; m<-0 until KW ; n<-0 until KW){
        s +=  V(iindex(l,j*ss+m,k*ss+n)) * K(i)(l)(m*KW+n)
      }
      Z(oindex(i,j,k)) = s
    }
    Z
  }

  def backward(G:Array[T]) = {

    val x = pop()
    n += 1d

    for(i<-0 until OC ;  j<-0 until IC ; k<-0 until KW ; l<-0 until KW){
      var s = 0d
      for(m<-0 until  OH ; n<-0 until OW){
        s += G(oindex(i,m,n)) * x(iindex(j,m*ss+k,n*ss+l))
      }

      D_K(i)(j)(k*KW+l) = s
    }

    val dV = Array.ofDim[Double](IC * IH * IW)

    for(i<-0 until IC ; j<-0 until IH ; k<-0 until IW){
      var s1=0d
      for(l <- math.max((j-KW)/ss,0) until math.min(j/ss+1,OH) ; m <- 0 until KW){
        if(j==l*ss+m){
          for(n <- math.max((k-KW)/ss,0) until math.min(k/ss+1,OW) ; p<-0 until KW){
            if(k==n*ss+p)
              for(q<-0 until OC)
                s1 += K(q)(i)(m*KW+p)*G(oindex(q,l,n))
          }
        }
      }
      dV(iindex(i,j,k)) = s1
    }
    dV
  }

  def update() {

    for(i<-0 until OC ; j<-0 until IC ; k<-0 until KW*KW){
      D_K(i)(j)(k) = D_K(i)(j)(k)/n
    }
    val p2 = 0.999
    val delta = 0.00000001

    var s_h = Array.ofDim[T](OC,IC,KW*KW)
    var r_h = Array.ofDim[T](OC,IC,KW*KW)
    
    t += 1

    p1_t = p1 * p1_t
    p2_t = p2 * p2_t

    for(i<-0 until OC ; j<-0 until IC ; k<-0 until KW*KW){
      var D_s = 0d//ΔΘ

      s(i)(j)(k) = p1*s(i)(j)(k)+(1-p1)*D_K(i)(j)(k)
      r(i)(j)(k) = p2*r(i)(j)(k)+(1-p2)*D_K(i)(j)(k)*D_K(i)(j)(k)

      s_h(i)(j)(k) = s(i)(j)(k)/(1-p1_t)
      r_h(i)(j)(k) = r(i)(j)(k)/(1-p2_t)

      D_s = -1*e*s_h(i)(j)(k)/(math.sqrt(r_h(i)(j)(k))+delta)
      K(i)(j)(k) = K(i)(j)(k) + D_s
     
    }
    n=0d
    reset()
  }

  def update2(){
    val lr = 0.9
    for(i<-0 until OC ; j<-0 until IC ; k<-0 until KW*KW)
      K(i)(j)(k) -= lr * D_K(i)(j)(k)
    reset()
  }

  def reset() {
    D_K = Array.ofDim[T](OC,IC,KW*KW)
  }

  override def save(fn:String) {
    val pw = new java.io.PrintWriter(fn)
    for(i <- 0 until OC ; j <- 0 until IC ; k <- 0 until KW*KW) {
      pw.write(K(i)(j)(k).toString)
      if(i != OC - 1 || j != IC-1 || k != KW*KW-1 ) {
        pw.write(",")
      }
    }
    pw.write("\n")
    pw.close()
  }

  override def load(fn:String) {
    val f = scala.io.Source.fromFile(fn).getLines.toArray
    val tmp = f(0).split(",").map(_.toDouble).toArray
    for(i <- 0 until OC ; j <- 0 until IC ; k <- 0 until KW*KW) {
      K(i)(j)(k) = tmp(i*IC*KW*KW+j*KW*KW+k)
    }
  }
}
